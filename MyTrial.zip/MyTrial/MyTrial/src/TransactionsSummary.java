

public class TransactionsSummary {

	private double amount, balance;

	public TransactionsSummary() {
	}

	public TransactionsSummary(double amount, double balance) {
		super();
		this.amount = amount;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return  amount +"\t"+ balance;
	}

	public char[] print() {
		return null;
	}

}
