import java.util.Scanner;

public class Trial1 {

	public static void main(String[] args) {

		TrialDao dao = new TrialDao();
		Scanner sc = new Scanner(System.in);

		int id;
		String name;
		double balance;

		while (true) {
			System.out.println("Enter Id");
			id = sc.nextInt();
			System.out.println("Enter Name");
			name = sc.next();
			System.out.println("Enter balance");
			balance = sc.nextDouble();

			TrialBean bean = new TrialBean(id, name, balance);


			dao.storeInToList(bean);
//			System.out.println("List is " + dao.displayList());

			System.out.println("Object value bean = " + bean);

			System.out.println("Enter to search");
			System.out.println("Enter Id");
			id = sc.nextInt();
			System.out.println("Enter Name");
			name = sc.next();
			System.out.println("Enter balance");
			balance = sc.nextDouble();
			TrialBean b1 = new TrialBean(id, name, balance);
			System.out.println("b1 value " + b1);

			
			System.out.println(dao.searchName(b1));

		}

	}
}
