package com.cg.mobileshop.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.cg.mobileshop.dto.Mobiles;
import com.cg.mobileshop.util.Util;

public class MobileDaoImpl {
private Map<Integer,Mobiles> mobileEntries=Util.getMobileEntries();
List<Mobiles> mobiles=null;
public List<Mobiles> getMobile(){
	if(mobiles==null)
	mobiles=new ArrayList<Mobiles>(mobileEntries.values()) ;
	return mobiles;
	
}
public void deleteMobile(int mobId) {
	mobiles.remove(new Mobiles(mobId, null, 0, 0));
}
public void sortMobile(int choice){
	switch (choice) {
	case 1:
		mobiles=mobiles.stream().sorted((obj1,obj2)-> obj1.getName().compareTo(obj2.getName())).collect(Collectors.toList());

		break;
	case 2:
		mobiles=mobiles.stream().sorted((obj1,obj2)-> obj1.getPrice()-(obj2.getPrice())).collect(Collectors.toList());
		break;
	case 3:
		mobiles=mobiles.stream().sorted((obj1,obj2)-> obj1.getMobileId()-(obj2.getMobileId())).collect(Collectors.toList());
		
		break;
	default:
		break;
	}
	
}
}
