package com.cg.mobileshop.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobileshop.dao.MobileDaoImpl;
import com.cg.mobileshop.dto.Mobiles;

public class MainUI {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	MobileDaoImpl dao=new MobileDaoImpl();
	int ch;
	int sortCh;
	int mobileid;
	while(true) {
		ArrayList<Mobiles> list= (ArrayList<Mobiles>) dao.getMobile();
		for (Mobiles mobile : list) {
			System.out.println(mobile);
		}
		System.out.println("1	Sorting\n2.	Delete\n3.	Exit");
		ch=sc.nextInt();
		switch (ch) {
		case 1:
			System.out.println("Select Any One option to sort Mobiles");
			System.out.println("1.	Mobile Name\n2.	Mobile Price\n3.	Mobile Id");
			sortCh=sc.nextInt();
			dao.sortMobile(sortCh);
			break;
		case 2:
			System.out.println("enter Mobile id to delete");
			mobileid=sc.nextInt();
			dao.deleteMobile(mobileid);
			break;
		case 3:
			System.exit(0);
		default:
			break;
		}
	}
}
}
