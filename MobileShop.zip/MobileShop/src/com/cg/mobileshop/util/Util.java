package com.cg.mobileshop.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.mobileshop.dto.Mobiles;

public class Util {

	private static Map<Integer, Mobiles> mobileEntries = new HashMap<Integer, Mobiles>();

	public static Map<Integer, Mobiles> getMobileEntries() {
		mobileEntries.put(1001, new Mobiles(1001, "Sony Experia", 12, 12000));
		mobileEntries.put(1002, new Mobiles(1002, "Samsung Note ", 4, 10000));
		mobileEntries.put(1003, new Mobiles(1003, "IPhone 3", 2, 23000));
		mobileEntries.put(1004, new Mobiles(1004, "Nokia Note 2322", 8, 10000));

		return mobileEntries;
	}
}
