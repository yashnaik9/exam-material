package com.cg.mobileshop.dto;

public class Mobiles {
private int mobileId;
private String name;
private int price;
private int quantity;
public int getMobileId() {
	return mobileId;
}
public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public Mobiles() {
}
public Mobiles(int mobileId, String name, int quantity, int price) {
	this.mobileId = mobileId;
	this.name = name;
	this.price = price;
	this.quantity = quantity;
}
@Override
public boolean equals(Object obj) {
if(obj instanceof Mobiles)
	return ((Mobiles)obj).getMobileId()==mobileId;
else return false;
}
@Override
public String toString() {
	return "mobileId=" + mobileId + ", name=" + name + ", price=" + price + ", quantity=" + quantity;
}

}
