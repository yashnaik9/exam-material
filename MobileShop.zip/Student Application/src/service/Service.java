package service;

import java.util.Map;

import bean.Student;
import bean.Teacher;
import exception.SchoolException;

public interface Service {

	String FirstChoice = "[1-4]{1}";
	String RChoice = "[1-2]{1}";

	boolean validateChoice(String choice);

	boolean validateRChoice(String rchoice);

	Map<Integer, Student> addToStudMap(Student s);

	Map<Integer, Teacher> addTOTeachMap(Teacher t);
	
	boolean findStudent(int id) throws SchoolException;
}
