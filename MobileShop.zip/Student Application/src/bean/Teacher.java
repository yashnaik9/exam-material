package bean;

import java.util.Date;

public class Teacher {

	private String name;
	private int age;
	private int id;
	private Date doj;
	
	public Teacher() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDoj() {
		return doj;
	}

	

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public Teacher(String name, int age, Date doj) {
		super();
		this.name = name;
		this.age = age;
		this.doj = doj;
	}
	
	@Override
	public String toString() {
		return "Teacher [name=" + name + ", age=" + age + ", id=" + id + ", doj=" + doj + "]";
	}
	
}
