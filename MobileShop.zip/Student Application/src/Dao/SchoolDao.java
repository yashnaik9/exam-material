package Dao;

import java.util.HashMap;
import java.util.Map;

import bean.Student;
import bean.Teacher;
import exception.SchoolException;

public interface SchoolDao {


	
	
	Map<Integer,Student>addToStudMap(Student s);
	Map<Integer,Teacher>addTOTeachMap(Teacher t);
	
	boolean findStudent(int id) throws SchoolException;
	
}
