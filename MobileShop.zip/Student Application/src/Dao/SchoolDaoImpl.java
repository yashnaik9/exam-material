package Dao;

import java.util.HashMap;
import java.util.Map;

import bean.Student;
import bean.Teacher;
import exception.SchoolException;

public class SchoolDaoImpl implements SchoolDao{
	private Map<Integer,Student>studmap = new HashMap<>();
	private Map<Integer,Teacher>teachmap = new HashMap<>();

	@Override
	public Map<Integer, Student> addToStudMap(Student s) {
		studmap.put(s.getId(), s);
		return studmap;
	}

	@Override
	public Map<Integer, Teacher> addTOTeachMap(Teacher t) {
		teachmap.put(t.getId(), t);
		return teachmap;
	}

	@Override
	public boolean findStudent(int id) throws SchoolException {
		if(studmap.containsKey(id)) {
		System.out.println(studmap.get(id));
		return true;
		}
		
		else
			
				throw new SchoolException("You Need to register First");
			
		
	}

	
	
	
	

}
