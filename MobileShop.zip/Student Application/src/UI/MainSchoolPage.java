package UI;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import Dao.SchoolDaoImpl;
import bean.Student;
import bean.Teacher;
import exception.SchoolException;
import service.ServiceImpl;

public class MainSchoolPage {

	public static void main(String[] args) {
		// variables
		String firstChoice;
		boolean isValid;
		String rchoice;
		// Scanner Class for input
		Scanner sc = new Scanner(System.in);
		// Service Class
		ServiceImpl service = new ServiceImpl();
		SchoolDaoImpl SDI = new SchoolDaoImpl();
		// bean class
		
		
		// date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/mm/dd");

		// main Ui
		System.out.println("Welcome to new School");
		SwitchLoop: while (true) {
			FchoiceLoop: while (true) {
				System.out.println(
						"please select the option from the choice below : \n1.Login as a Teacher \n2.Login as a Student \n3.Register a new Profile \n4.Exit");
				firstChoice = sc.next();
				isValid = service.validateChoice(firstChoice);
				if (isValid)
					break FchoiceLoop;
				else
					try {
						throw new SchoolException("Please enter a valid choice between 1 to 4");
					} catch (SchoolException e) {
						System.out.println(e);
					}

			}
			switch (firstChoice) {

			case "1":
				System.out.println("Login as a Teacher");

				break;

			case "2":
				
				System.out.println("Please Enter Your Student Id for Login");
				int id =sc.nextInt();
				try {
					service.findStudent(id);
				} catch (SchoolException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1);
				}
				
				break;

			case "3":
				System.out.println("Register a new profile");

				Rchoice: while (true) {
					System.out.println("Please select an account for registration \n1. Student \n2.Teacher");
					rchoice = sc.next();
					isValid = service.validateRChoice(rchoice);
					if (isValid)
						break Rchoice;
					else
						try {
							throw new SchoolException("Enter a Valid Choice from 1 & 2");
						} catch (SchoolException e) {

							System.out.println(e);
						}

				}
				switch (rchoice) {
				case "1":
					System.out.println("Please Enter your name :");
					String name = sc.next();
					System.out.println("Please Enter your age :");
					int age = sc.nextInt();
					Date date = new Date();
					Student Stud = new Student();
					Stud.setName(name);
					Stud.setAge(age);
					Stud.setDoj(date);
					service.addToStudMap(Stud);
					System.out.println("You Have Successfully Registered as a Student");
					System.out.println("Your Student Id is :" + Stud.getId());
					System.out.println("Use This Id For SignIn to view Your Profile");
					
					break;

				case "2":
					System.out.println("Please Enter your name :");
					String tname = sc.next();
					System.out.println("Please Enter your age :");
					int tage = sc.nextInt();
					Date tdate = new Date();
					Teacher Teach = new Teacher();
					Teach.setName(tname);
					Teach.setAge(tage);
					Teach.setDoj(tdate);
					service.addTOTeachMap(Teach);
					System.out.println("You Have Successfully Registered as a Teacher");
					System.out.println("Your Student Id is :" + Teach.getId());
					System.out.println("Use This Id For SignIn to view Your Profile");
					break;

				}
				break;
			case "4":
				System.out.println("Thank you for visiting our School");
				System.exit(0);
				break SwitchLoop;
			}
		}
	}

}
