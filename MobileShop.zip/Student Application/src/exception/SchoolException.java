package exception;

public class SchoolException extends Exception {

	public SchoolException() {

	}

	public SchoolException(String msg) {
		
		super(msg);

	}
}
