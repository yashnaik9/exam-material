package service;

import java.util.Map;

import Dao.SchoolDao;
import Dao.SchoolDaoImpl;
import bean.Student;
import bean.Teacher;
import exception.SchoolException;

public class ServiceImpl implements Service {
	
	SchoolDaoImpl sdi = new SchoolDaoImpl();

	@Override
	public boolean validateChoice(String choice) {
		if(choice.matches(FirstChoice))
		return true;
		else
		return false;
	}

	@Override
	public boolean validateRChoice(String rchoice) {
		if(rchoice.matches(RChoice))
		return true;
		else
		return false;
	}

	@Override
	public Map<Integer, Student> addToStudMap(Student s) {
		int Id = (int) (1234*Math.random()*100);
		s.setId(Id);
		
		return sdi.addToStudMap(s);
	}

	@Override
	public Map<Integer, Teacher> addTOTeachMap(Teacher t) {
		int Id = (int) (1234*Math.random()*100);
		t.setId(Id);
		
		return sdi.addTOTeachMap(t);
		
	}

	@Override
	public boolean findStudent(int id) throws SchoolException {
		sdi.findStudent(id);
		return false;
	}

	@Override
	public boolean findTeacher(int idt) throws SchoolException {
		sdi.findTeacher(idt);
		return false;
	}

	

	
}
