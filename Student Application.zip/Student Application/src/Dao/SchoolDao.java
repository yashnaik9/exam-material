package Dao;

import java.util.List;
import java.util.Map;

import bean.Student;
import bean.Teacher;
import exception.SchoolException;

public interface SchoolDao {


	
	
	Map<Integer,Student>addToStudMap(Student s);
	Map<Integer,Teacher>addTOTeachMap(Teacher t);
	
	boolean findStudent(int id) throws SchoolException;
	boolean findTeacher(int id) throws SchoolException;
	
	List<Student>getstudList();
	
}
