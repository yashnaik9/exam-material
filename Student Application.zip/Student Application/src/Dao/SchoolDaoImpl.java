package Dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bean.Student;
import bean.Teacher;
import exception.SchoolException;

public class SchoolDaoImpl implements SchoolDao {
	private Map<Integer, Student> studmap = new HashMap<>();
	private Map<Integer, Teacher> teachmap = new HashMap<>();
	ArrayList<Student> studList = new ArrayList<>(studmap.values());

	@Override
	public Map<Integer, Student> addToStudMap(Student s) {
		studmap.put(s.getId(), s);
		return studmap;
	}

	@Override
	public Map<Integer, Teacher> addTOTeachMap(Teacher t) {
		teachmap.put(t.getId(), t);
		return teachmap;
	}

	@Override
	public boolean findStudent(int id) throws SchoolException {
		if (studmap.containsKey(id)) {
			System.out.println(studmap.get(id));
			return true;
		}

		else

			throw new SchoolException("You Need to register First");

	}

	@Override
	public List<Student> getstudList() {
		List<Student> stud = new ArrayList<>(studmap.values());
		
		return stud;
	}

	@Override
	public boolean findTeacher(int id) throws SchoolException {
		if (teachmap.containsKey(id)) {
			System.out.println("Welcome to Your Teachers Account");
			System.out.println("The list of Student is as follows");
			List<Student> stud =getstudList();
			for (Student student : stud) {
				System.out.println(student);

			}
			return true;
		}

		else

			throw new SchoolException("You Need to register First");

	}
}
