package com.cg.ui;
/**
 * 
 */
import java.util.Scanner;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;
import com.cg.service.ProductServiceImpl;
/**
 * 
 * @author yash naik
 * @version 1.0
 */
public class Shopping {
	
	public static void main(String[] args) {
		// variables 
		String firstChoice;
		boolean isValid;
		//Service Class
		ProductServiceImpl service = new ProductServiceImpl();
		
		//Scanner Class for input
		Scanner sc = new Scanner (System.in);
		
		//main Ui
		
		System.out.println("Shopping Market");
		SwitchLoop:while(true){
		FirstChoiceloop:while(true){
		System.out.println("Please select the option given below : \n1.Add Product \n2.Delete Product \n3.Sort Product \n4.Exit");
		firstChoice = sc.next();
		isValid = service.validateFChoice(firstChoice);
		if(isValid)
		break FirstChoiceloop;
		else
			try {
				throw new InvalidProductException("Please select a valid choice");
			} catch (InvalidProductException e) {
				System.out.println(e);
			}
		}
		switch(firstChoice){
		
		case "1" :
			System.out.println("Please Enter the name of the product");
			String name = sc.next();
			System.out.println("Please Enter Price of the product");
			double price = sc.nextDouble();
			Product prod = new Product();
			prod.setName(name);
			prod.setPrice(price);
			service.addProduct(prod);
			System.out.println("You have successfully added " +name);
			System.out.println("The Id of your Product is "+prod.getId());
			break;
		case "2" :
			System.out.println("Please Enter the Id of the product that you wish delete");
			int id = sc.nextInt();
			try {
				service.removeProduct(id);
				System.out.println("You have Successfully deleted the Product" +id);
			} catch (InvalidProductException e) {
				System.out.println(e);
			}
			break;
		case "3" :
			System.out.println("Please Select the choice to sort :");
			System.out.println("1.Sort by name \n2.Sort by Price");
			String sortChoice = sc.next();
			switch(sortChoice){
			case "1":
				for (Product product : service.sortByName()) {
					System.out.println(product);
				}
				break;
			case "2":
				for (Product product : service.sortByPrice()) {
					System.out.println(product);
				}
				break;
			}
			break;
			
		case "4" :
			System.out.println("Thanks for Your intrest");
			System.exit(0);
			break;
		}
		
		
	}//switch loop

}

}
