package com.cg.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bean.Product;
import com.cg.service.ProductServiceImpl;

/**
 * this class is the test of Service
 * @author yasnaik
 * @version 1.0
 */
public class TestProductService {

	private ProductServiceImpl service;
	@Before
	public void init(){
		service = new ProductServiceImpl();
	}
	
	@Test
	public void testAddProduct(){
		Product p = new Product();
		p.setName("iphone");
		p.setPrice(1000);
		service.addProduct(p);
		
	}
	
	@After
	public void flush(){
		service = null;
	}
}
