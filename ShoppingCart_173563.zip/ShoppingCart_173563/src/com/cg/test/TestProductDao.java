package com.cg.test;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bean.Product;
import com.cg.dao.ProductDaoImpl;
import com.cg.exception.InvalidProductException;

/**
 * This class is the test calss of product Dao
 * @author yasnaik
 * @version 1.0
 */
public class TestProductDao {

	private ProductDaoImpl productDao=  null;
	
	@Before
	public void inti()
	{
	
		productDao=new ProductDaoImpl();
	}
	
	@After
	public void teardown()
	{
		productDao=null;
	}
	
	@Test
	public void addProduct(){
		Product p = new Product();
		p.setName("Saikat");
		p.setId(1);
		p.setPrice(50);
		productDao.saveProduct(1, p);
	}
	

	@Test ()
	public void testDelete1() throws InvalidProductException
	{
		Product p = new Product();
		p.setName("Saikat");
		p.setId(2);
		p.setPrice(50);
		productDao.saveProduct(p.getId(), p);
		productDao.deleteProduct(2);
		Assert.assertEquals(true, true);
		
	}
	@Test ()
	public void testDelete2() throws InvalidProductException
	{
		Product p = new Product();
		p.setName("Saikat");
		p.setId(2);
		p.setPrice(50);
		Product p1 = new Product();
		p1.setName("Saikat");
		p1.setId(3);
		p1.setPrice(50);
		productDao.saveProduct(2, p);
		productDao.saveProduct(3, p);
		productDao.deleteProduct(2);
		Assert.assertEquals(true, true);
		
	}
	
	@Test (expected = InvalidProductException.class)
	public void testDelete() throws InvalidProductException
	{
		ProductDaoImpl pro = new ProductDaoImpl();
		pro.deleteProduct(3);
	}
	
}
