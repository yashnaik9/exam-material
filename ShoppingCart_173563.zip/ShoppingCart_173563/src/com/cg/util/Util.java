package com.cg.util;

import java.util.HashMap;

import com.cg.bean.Product;

/**
 * 
 * @author yasnaik
 *
 */
public class Util {

	public static HashMap<Integer,Product>getMap(){
		HashMap<Integer,Product>map = new HashMap<>();
		Product p1 = new Product();
		p1.setName("Iphone");
		p1.setPrice(1000);
		p1.setId(3);
		
		Product p2 = new Product();
		p2.setId(1);
		p2.setName("Samsung");
		p2.setPrice(20000);
		
		
		
		map.put(3, p1);
		map.put(1, p2);
		
		
		return map;
		
	}
}
