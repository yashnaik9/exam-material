/**
 * 
 */
package com.cg.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;
import com.cg.util.Util;

/**
 * @author yasnaik
 *
 */
public class ProductDaoImplUtil implements ProductDao {

	private HashMap<Integer,Product> map;
	

	public ProductDaoImplUtil() {
 
		map=Util.getMap();
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.dao.ProductDao#saveProduct(int, com.cg.bean.Product)
	 */
	@Override
	public boolean saveProduct(int id, Product p) {

		map.put(p.getId(), p);

		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.dao.ProductDao#deleteProduct(int)
	 */
	@Override
	public boolean deleteProduct(int id) throws InvalidProductException {
		if(map.containsKey(id)){
			map.remove(id);
			return true;
		}
		throw new InvalidProductException("Product with Id not found"+id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.dao.ProductDao#getProducts()
	 */
	@Override
	public Collection<Product> getProducts() {
		return  map.values();
	}

}
