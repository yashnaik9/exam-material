package com.cg.dao;

import java.util.Collection;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;

/**
 * This is public interface of Product Dao
 * @author yasnaik
 * @version 1.0
 */
public interface ProductDao {
	/**
	 * Adds a Product
	 * @param id
	 * @param p
	 * @return flag
	 */

	boolean saveProduct(int id, Product p);
	
	/**
	 * Deletes a product
	 * @param id
	 * @return flag
	 * @throws InvalidProductException
	 */
	
	boolean deleteProduct(int id)throws InvalidProductException;
	
	/**
	 * Returns all products
	 * @return product
	 */
	
	Collection<Product> getProducts();
}
