/**
 * 
 */
package com.cg.service;

import java.util.Comparator;
import java.util.Random;
import java.util.TreeSet;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImplUtil;
import com.cg.exception.InvalidProductException;

/**
 * @author yasnaik
 *
 */
public class ProductServiceImpl implements ProductService {

	private ProductDao dao;

	public ProductServiceImpl() {
		dao = new ProductDaoImplUtil();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.service.ProductService#addProduct(com.cg.bean.Product)
	 */
	@Override
	public int addProduct(Product p) {
		int id = new Random().nextInt(1000);
		p.setId(id);
		dao.saveProduct(id, p);
		return id;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.service.ProductService#removeProduct(int)
	 */
	@Override
	public boolean removeProduct(int id) throws InvalidProductException {
		return dao.deleteProduct(id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.service.ProductService#sortByName()
	 */
	@Override
	public TreeSet<Product> sortByName() {
		Comparator<Product> pc = (p1, p2) -> p1.getName().compareTo(
				p2.getName());

		TreeSet<Product> tree = new TreeSet<Product>(pc);
		tree.addAll(dao.getProducts());

		return tree;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.service.ProductService#sortByPrice()
	 */
	@Override
	public TreeSet<Product> sortByPrice() {

		Comparator<Product> pc = (p1, p2) -> (int) (p1.getPrice() - p2
				.getPrice());

		TreeSet<Product> tree = new TreeSet<Product>(pc);
		tree.addAll(dao.getProducts());

		return tree;
	}

	/**
	 * validate choice
	 */
	@Override
	public boolean validateFChoice(String choice) {
		if (choice.matches(FirstChoice))
			return true;
		else
			return false;
	}

}
