/**
 * 
 */
package com.cg.service;

import java.util.TreeSet;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;

/**
 * This is a public serviceInterface of Service
 * @author yash naik
 * @version 1.0
 */
public interface ProductService {
	
	String FirstChoice = "[1-4]{1}";
	

	/**
	 * 
	 * @param p
	 * @return
	 */
	int addProduct(Product p);
	
	boolean validateFChoice(String choice);
	boolean removeProduct(int id)throws InvalidProductException;
	
	TreeSet<Product>sortByName();
	TreeSet<Product>sortByPrice();
}
