package com.cg.bean;
/**
 * This is the bean class of product
 * @author yasnaik
 * @version 1.0
 * 
 */
public class Product {

	private String name;
	private double price;
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return " name = " + name + "\tprice=" + price +" \tid = "+ id;
	}
	
	
}
