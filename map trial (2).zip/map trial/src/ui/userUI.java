package ui;

import java.util.Scanner;

public class userUI {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String choice ;
		
		System.out.println("Welcome to my map add");
		
		System.out.println("Please Select the option from the given choice");
		floop: while(true){
		System.out.println("1.Register as new student \n2.Check Your Student Profile \n3.Exit");
	    choice = sc.next();
		
		
	    break floop;
		}
	}
}
