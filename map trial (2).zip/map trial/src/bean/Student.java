package bean;

public class Student {
	String name;
	int id;
	int division;

	public Student() {
		
	}

	public Student(String name, int id, int division) {
		this.name = name;
		this.id = id;
		this.division = division;
	}
	
	
}
